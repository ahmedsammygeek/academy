<?php

class TVeez_Channel extends TVeez_Component
{
	/*
	 * - status: free or paid
		- category
		- frequency
	 */
	
	public function __construct($item_id = 0)
	{
		parent::__construct($item_id);
		
		$this->form_fields['channel_type'] = array(
				'label' => 'Type',
				'type' => 'radio',
				'data_type' => 'string',
				'value' => '',
				'values' => array(
						'free' => 'Free',
						'paid' => 'Paid',
				),
		);
		
		$this->form_fields['frequencies'] = array(
				'label' => 'Frequencies', 
				'type' => 'html', 
				'data_type' => 'array', 
				'value' => array(), 
				'html' => ''
		);
		
		$this->form_fields['desc_en'] = array(
				'label' => 'Description in English',
				'type' => 'textarea',
				'data_type' => 'string',
				'value' => '',
				'class' => 'large-text',
				'rows' => '10',
		);

		$this->form_fields['desc_ar'] = array(
				'label' => 'Description in Arabic',
				'type' => 'textarea',
				'data_type' => 'string',
				'value' => '',
				'class' => 'large-text',
				'rows' => '10',
				'dir' => 'rtl',
		);

		$this->form_fields['widget_use'] = array(
				'label' => 'Widget Use',
				'label_next' => '',
				'type' => 'checkbox',
				'data_type' => 'string',
				'value' => '',
				'is_singular' => true,
				'input_data' => array('label' => 'Show in Widget', 'value' => 'yes'),
		);
	}
	
	public function save_meta_values($return = false)
	{
		$parent = parent::save_meta_values($return);
		
		if(isset($_POST['freqs']) && is_array($_POST['freqs']))
		{
			$freqs = array_unique(array_map('floatval', $_POST['freqs']));
			delete_post_meta($this->ID, 'frequencies');
			foreach ($freqs as $freq)
			{
				add_post_meta($this->ID, 'frequencies', $freq);
			}
		}
		
		if($return)
			return $parent;
	}
	
	public function get_field_value($field, $return_value = true, $args = array())
	{
		if(!$args)
			$args = array();
	
		$value = null;
		if('frequencies' == $field && isset($args['details']) && $args['details'])
		{
			$freq_ids = parent::get_field_value($field, $return_value, $args);

			$value = array(
					'details' => array(), 
					'full_text' => array()
			);

			foreach ($freq_ids as $i => $id)
			{
				$value['details'][$i] = tveez_get_frequencies($id)->freq_data;
				$value['full_text'][$i] = tveez_parse_frequency_string(&$value['details'][$i]);
			}
		}
		elseif('schedule' == $field)
		{
			$args = array_merge(array('today' => true, 'next' => true, 'order_by' => 'start_time'), $args);
			$value = tveez_get_schedule(null, $this->ID, '*', $args);
		}
		else
		{
			$lang_field = $field . '_' . tveez_lang();
			if(isset($this->form_fields[$lang_field]))
				$value = parent::get_field_value($lang_field, $return_value, $args);
			else
				$value = parent::get_field_value($field, $return_value, $args);
		}
	
		if ($return_value)
			return $value;
	}
	
	public function data_output($fields = array(), $type = 'array')
	{
		$defaults = array('id' => NULL, 'title' => NULL, 'image_thum' => NULL);
		if('full' == $fields || (is_array($fields) && isset($fields[0]) && 'full' == $fields[0]))
		{
			$extra = array(
					'image_big' => NULL,
					'channel_type' => NULL, 
					'lang' => NULL,
					'frequencies' => array('single' => false, 'details' => true), 
					'desc' => NULL, 
					'cats' => array('fields' => 'names')
			);
			if(is_array($fields) && isset($fields['schedule_attr']))
				$extra['schedule'] = $fields['schedule_attr'];
			
			$defaults = array_merge($defaults, $extra);
		}
		else
		{
			$defaults = wp_parse_args($fields, $defaults);
		}
	
		return parent::data_output($defaults, $type);
	}
	
	/**
	 * Get All Channels
	 * 
	 * @param boolean $class
	 * @return array if $class is true it will return array of TVeez_Channel objects, otherwise it will return array of db objects
	 */
	public static function get_channels($class = false)
	{
		$channels = get_posts(array('post_type' => TVEEZ_CHANNEL, 'nopaging' => true));
		$count = count($channels);
		if($count && $class)
		{
			for ($i =0; $i < $count; $i++)
			{
				$channels[$i] = new TVeez_Channel($channels[$i]);
			}
		}
		return $channels;
	}
}
