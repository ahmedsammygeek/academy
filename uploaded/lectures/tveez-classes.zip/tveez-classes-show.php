<?php

class TVeez_Show extends TVeez_Component
{
	/*
	 * show type: 
	 * - show times: channel, date, time and repeat
		- description
	 */
	
	/**
	 * Number of likes
	 *
	 * @var int
	 */
	var $likes = 0;
	
	/**
	 * Date and times Timezone 
	 *
	 * @var string
	 */
	var $timezone = '+0';
	
	/**
	 * Show type 
	 *
	 * @var string
	 */
	var $show_type = '';
	
	/**
	 * Schedule base datetime (GMT)
	 *
	 * @var string
	 */
	var $schedule_base = '';
	
	public function __construct($item_id = 0)
	{
		parent::__construct($item_id);
		
		$this->form_fields['show_type'] = array(
				'label' => 'Show Type',
				'type' => 'radio',
				'data_type' => 'string',
				'value' => '',
				'values' => array(
						'movie' => 'Movie',
						'series' => 'Series',
						'sport' => 'Sport',
						'theatre' => 'Theatre',
						'program' => 'Program',
				),
		);
		
		$this->form_fields['desc_en'] = array(
				'label' => 'Description in English', 
				'type' => 'textarea', 
				'data_type' => 'string', 
				'value' => '', 
				'class' => 'large-text',
				'rows' => '10',
		);
		
		$this->form_fields['desc_ar'] = array(
				'label' => 'Description in Arabic', 
				'type' => 'textarea', 
				'data_type' => 'string', 
				'value' => '', 
				'class' => 'large-text', 
				'rows' => '10',
				'dir' => 'rtl',
		);
		
		$this->form_fields['schedule'] = array(
				'label' => 'Schedule', 
				'label_next' => '', 
				'type' => 'html', 
				'data_type' => 'array', 
				'value' => array(),
				'html' => '',
		);
		
		$this->show_type = $this->get_field_value('show_type');
		if('movie' == $this->show_type || 'series' == $this->show_type || 'theatre' == $this->show_type)
		{
			$this->form_fields['director_en'] = array(
				'label' => 'Director in English', 
				'type' => 'text', 
				'data_type' => 'string', 
				'value' => '', 
				'class' => 'regular-text', 
			);
			$this->form_fields['director_ar'] = array(
				'label' => 'Director in Arabic', 
				'type' => 'text', 
				'data_type' => 'string', 
				'value' => '', 
				'class' => 'regular-text', 
				'dir' => 'rtl'
			);
			$this->form_fields['stars_en'] = array(
				'label' => 'Stars in English', 
				'type' => 'text', 
				'data_type' => 'string', 
				'value' => '', 
				'class' => 'large-text', 
			);
			$this->form_fields['stars_ar'] = array(
				'label' => 'Stars in Arabic', 
				'type' => 'text', 
				'data_type' => 'string', 
				'value' => '', 
				'class' => 'large-text', 
				'dir' => 'rtl'
			);
		}
		elseif ('sport' == $this->show_type)
		{
			$this->form_fields['event_type_en'] = array(
					'label' => 'Event Type in English',
					'type' => 'text',
					'data_type' => 'string',
					'value' => '',
					'class' => 'regular-text',
			);
			$this->form_fields['event_type_ar'] = array(
					'label' => 'Event Type in Arabic',
					'type' => 'text',
					'data_type' => 'string',
					'value' => '',
					'class' => 'regular-text',
					'dir' => 'rtl'
			);
		}
		elseif ('program' == $this->show_type)
		{
			$this->form_fields['presenter_en'] = array(
					'label' => 'Presenter in English',
					'type' => 'text',
					'data_type' => 'string',
					'value' => '',
					'class' => 'regular-text',
			);
			$this->form_fields['presenter_ar'] = array(
					'label' => 'Presenter in Arabic',
					'type' => 'text',
					'data_type' => 'string',
					'value' => '',
					'class' => 'regular-text',
					'dir' => 'rtl'
			);
		}
		
		$this->form_fields['is_featured'] = array(
				'label' => 'Featured Show',
				'label_next' => '',
				'type' => 'checkbox',
				'data_type' => 'string',
				'value' => '',
				'is_singular' => true,
				'input_data' => array('label' => 'Make it featured', 'value' => 'yes'),
		);
		
		$this->form_fields['panorama'] = array(
				'label' => 'Panorama Image',
				'label_next' => '923 x 316 pixels',
				'type' => 'image',
				'data_type' => 'array',
				'value' => array(),
				'media_library' => true,
		);
	}

	public function get_field_value($field, $return_value = true, $args = array())
	{
		if(!$args)
			$args = array();

		switch ($field)
		{
			case 'running_time':
				$this->current_time = current_time('timestamp', true);
				$this->start_time = strtotime($this->post_object->date .' '. $this->post_object->start_time);
				$this->end_time = strtotime($this->post_object->end_date .' '. $this->post_object->end_time);

				//$value = date('H:i', $this->current_time - $this->start_time);
				$value = floor(($this->current_time - $this->start_time) / 60);
				break;

			case 'running_percent':
				$duration = $this->end_time - $this->start_time;
				$left = $this->current_time - $this->start_time;
				$value = round(($left / $duration)*100);
				break;

			case 'start_time':
				if(isset($this->post_object->start_time))
					$value =& ng_convert_datetime($this->post_object->start_time, $this->timezone);
				else
					$value = '';
				break;

			case 'end_time':
				if(isset($this->post_object->end_time))
					$value =& ng_convert_datetime($this->post_object->end_time, $this->timezone);
				else
					$value = '';
				break;

			case 'channel_logo':
				if(isset($this->post_object->channel_id))
				{
					$image_id = TVeez_Channel::load_image_id($this->post_object->channel_id);
					$value = TVEEZ_CHANNEL::get_image_url($image_id, true);
				}
				else
				{
					$value = '';
				}
				break;

			case 'schedule':
				$this->form_fields[$field]['value'] = tveez_get_schedule($this->ID, 0, '*', $args);
				$value =& $this->form_fields[$field]['value'];
				break;

			case 'schedule_front':
				$extra = array(
					'next' => true, 
					'datetime' => $this->schedule_base, 
					'timezone' => $this->timezone,
					'channel_info' => array('url' => null),
				);

				if(!isset($extra['meta']) || !is_array($extra['meta']))
					$extra['meta'] = array();

				$extra['meta'] = array_merge($extra['meta'], array('replay', 'note'));

				$args = array_merge($args, $extra);
				$value = tveez_get_schedule($this->ID, 0, 'sch_id, channel_id, date, start_time', $args);
				break;
			
			case 'next_at':
				$extra = array(
					'next' => true, 
					'datetime' => gmdate('Y-m-d H:i:s'), 
					'timezone' => $this->timezone,
					'limit' => '1',
					'channel_info' => array('url' => NULL),
				);
				$args = array_merge($args, $extra);
				$value = tveez_get_schedule($this->ID, 0, 'channel_id, date, start_time', $args);
				if(count($value))
					$value = $value[0];
				else
					$value = false;
				break;

			case 'likes':
				if($this->likes && $return_value)
					return $this->likes;

				$this->likes = floatval(get_post_meta($this->ID, 'tveez_likes', true));
				$value =& $this->likes;
				break;
			
			default:
				$lang_field = $field . '_' . tveez_lang();
				if(isset($this->form_fields[$lang_field]))
					$value = parent::get_field_value($lang_field, $return_value, $args);
				else
					$value = parent::get_field_value($field, $return_value, $args);
		}
		
		if($return_value)
			return $value;
	}

	public function data_output($fields = array(), $type = 'array')
	{
		$defaults = array('id' => NULL, 'title' => NULL, 'image_thum' => NULL, 'show_type' => NULL, 'likes' => NULL);
		if('full' == $fields)
		{
			$defaults['image_big'] = NULL;
			$defaults['lang'] = NULL;
			$defaults['desc'] = NULL;
			if('movie' == $this->show_type || 'series' == $this->show_type || 'theatre' == $this->show_type)
			{
				$defaults['director'] = NULL;
				$defaults['stars'] = NULL;
				if('series' == $this->show_type)
					$defaults['next_eps'] = NULL;
			}
			elseif ('sport' == $this->show_type)
			{
				$defaults['event_type'] = NULL;
			}
			elseif ('program' == $this->show_type)
			{
				$defaults['presenter'] = NULL;
			}
			$defaults['schedule_front'] = NULL;
			$defaults['cats'] = array('fields' => 'names');
		}
		else
		{
			$defaults = wp_parse_args($fields, $defaults);
		}
		return parent::data_output($defaults, $type);
	}
}


















