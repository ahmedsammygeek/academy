<?php

class TVeez_Component
{
	/**
	 * - title
		- image or logo
		- language
	 */
	
	/**
	 * Component ID
	 * 
	 * @var int
	 */
	var $ID;

	/**
	 * Component WP_Post object retrieved
	 * 
	 * @var WP_Post
	 */
	var $post_object;

	/**
	 * WP_Post object properties
	 * 
	 * @var array
	 */
	protected $post_vars;
	
	/**
	 * Component Image information 
	 * 
	 * @var array
	 */
	var $image = array();
	
	/**
	 * Component language en|ar
	 * 
	 * @var string
	 */
	var $language;
	
	/**
	 * Component Categories
	 *
	 * @var array
	 */
	var $categories;
	
	/**
	 * Component backend fields
	 * 
	 * @var array
	 */
	protected $form_fields = array (
			'title_ar' => array('label' => 'Name in Arabic', 'type' => 'text', 'data_type' => 'string', 'value' => '', 'class' => 'regular-text', 'dir' => 'rtl'),
			'lang' => array('label' => 'Language', 'type' => 'radio', 'data_type' => 'string', 'value' => '', 'values' => array('ar' => 'Arabic', 'en' => 'English'), 'class' => 'regular-text'),
	);
	
	public function __construct($item_id = 0)
	{
		if (is_object($item_id) && isset($item_id->ID))
		{
			if(!is_a($item_id, 'WP_Post'))
				$item_id = new WP_Post($item_id);

			$this->post_object = $item_id;
			$this->ID = $item_id->ID;
		}
		else
		{
			$this->ID = $item_id;
			$this->post_object = get_post($this->ID);
		}

		$this->post_object->filter = 'raw';
		$this->post_vars = get_object_vars($this->post_object);

		$this->image['id'] = $this->load_image_id($this->ID);
		if('' == $this->image['id'])
			$this->image = array('id' => 0, 'thum' => '', 'big' => '');
		
	}

	/**
	 * Get Object Permalink URL
	 * 
	 * @return String
	 */
	public function url()
	{
		return get_permalink($this->ID);
	}
	
	/**
	 * Check if object exists in db or not
	 * 
	 * @return boolean
	 */
	public function exists()
	{
		return $this->post_object ? true : false;
	}
	
	public static function load_image_id($com_id)
	{
		return get_post_thumbnail_id($com_id);
	}
	
	/**
	 * Get output data for frontend usage
	 *
	 * @param array $fields wanted fields
	 * @return mixed returns the output data in array or object
	 */
	public function data_output($fields = array(), $type = 'array')
	{
		$fields = wp_parse_args($fields, array('id' => NULL, 'title' => NULL, 'image_thum' => NULL));
		if('array' == $type)
			$output = array();
		else
			$output = new stdClass();

		$is_array = 'array' == $type;
		foreach ($fields as $field => $args)
		{
			if($is_array)
				$output[$field] = $this->get_field_value($field, true, $args);
			else
				$output->$field = $this->get_field_value($field, true, $args);
		}
	
		return $output;
	}
	
	/**
	 * Get image  
	 * 
	 * @param int $image_id
	 * @param boolean $thum
	 * @return string|boolean false on failure, if $thum is true thumbnail url will be returned or the big image url
	 */
	public static function get_image_url($image_id, $thum)
	{
		$size = 'tveez_big';
		if($thum)
			$size = 'tveez_thumb';
		
		$downsize = image_downsize($image_id, $size);
		if(!$downsize)
			return '';

		if($downsize[3])
			return $downsize[0]; // image already generated and returend
		
		// require needed file
		require_once(ABSPATH . 'wp-admin' . '/includes/image.php');
		
		// 5 min per regenerating
		@set_time_limit(300); 
		
		// get image file info
		$file = get_attached_file($image_id);
		if(!$file)
			return '';
		
		// regenerate metadata with file sizes
		$metadata = wp_generate_attachment_metadata($image_id, $file);
		//dump_data($metadata);
		if(is_wp_error($metadata))
			return '';
		
		// update image post
		wp_update_attachment_metadata($image_id, $metadata);
		
		// recall image size
		$downsize = image_downsize($image_id, $size);
		return $downsize[0];
	}
	
	/**
	 * Get Component categories
	 *
	 * @param array $args arguments to pass
	 * @return array list of categories attached to that show
	 */
	public function get_categories($args = array())
	{
		// defaults
		$defaults = array(
				'fields' => 'all',
		);
		$args = wp_parse_args($args, $defaults);
		
		if('names' == $args['fields'])
			$pass_args = array('fields' => 'all');
		else
			$pass_args =& $args;
			
		$cats = wp_get_post_terms($this->ID, TVEEZ_CATEGORIES, $pass_args);
		if(is_array($cats))
		{
			$this->categories = $cats;
			if('ids' == $args['fields'] || 'slugs' == $args['fields'])
				return $cats;
			
			$count = count($cats);
			if($count)
			{
				$arabic = 'ar' == tveez_lang();
				if('names' == $args['fields'])
				{
					$out = array();
					for($i = 0; $i < $count; $i++)
					{
						$out[] = $arabic ? tveez_get_term_meta($cats[$i]->term_id, 'name_ar') : $cats[$i]->name;
					}
					return $out;
				}
				else
				{
					for($i = 0; $i < $count; $i++)
					{
						unset($cats[$i]->term_group, $cats[$i]->term_taxonomy_id, $cats[$i]->taxonomy, $cats[$i]->description);
					}
					return $cats;
				}
			}
		}
		return array();
	}
	
	/**
	 * Get meta value
	 * 
	 * @param string $field meta key
	 * @param boolean $return_value to return the value or not
	 * @param array $args
	 * @return mixed if $return_value is true the value will be returned
	 */
	public function get_field_value($field, $return_value = true, $args = array())
	{
		if(!$args)
			$args = array();

		$value = null;
		switch($field)
		{
			case 'id':
				$value =& $this->ID;
				break;

			case 'title':
				if('ar' == tveez_lang())
					$value =& $this->get_field_value('title_ar', $return_value, $args);
				else
					$value =& $this->post_object->post_title;
				break;

			case 'image_thum':
				if(!isset($this->image['thum']) || '' == $this->image['thum'])
					$this->image['thum'] = $this->get_image_url($this->image['id'], true);
				
				$value =& $this->image['thum'];
				break;

			case 'image_big':
				if(!isset($this->image['big']) || '' == $this->image['big'])
					$this->image['big'] = $this->get_image_url($this->image['id'], false);
				
				$value =& $this->image['big'];
				break;

			case 'url':
				$value =& get_permalink($this->ID);
				break;

			case 'cats':
				$value =& $this->get_categories($args);
				break;
			
			default:
				if(isset($this->post_vars[$field]))
				{
					$value =& $this->post_vars[$field];
				}
				else
				{
					$args = wp_parse_args($args, array('single' => true));
					if($args['single'])
						$this->form_fields[$field]['value'] = $this->post_object->$field;
					else
						$this->form_fields[$field]['value'] = get_post_meta($this->ID, $field, $args['single']);

					$value =& $this->form_fields[$field]['value'];
				}
				break;
		}
		
		if ($return_value)
			return $value;
	}
	
	/**
	 * change form field data attributes 
	 * 
	 * @param string $field field name
	 * @param string $attr attribute name
	 * @param mixed $data attribute data value
	 */
	public function set_field_attr($field, $attr, $data)
	{
		if(!isset($this->form_fields[$field]) || !isset($this->form_fields[$field][$attr]))
			return false;
		
		$this->form_fields[$field][$attr] = $data;
	}
	
	/**
	 * get meta values and put them at the right position
	 */
	protected function meta_values()
	{
		foreach ($this->form_fields as $field => $attrs)
		{
			if('' == $this->form_fields[$field]['value'] || array() === $this->form_fields[$field]['value'])
				$this->get_field_value($field, false);
		}
	}
	
	/**
	 * Save meta values
	 * 
	 * @param boolean $return if true result output array will be returned
	 * @return array return with output status and possible errors 
	 */
	public function save_meta_values($return = false)
	{
		foreach ($this->form_fields as $field => $attrs)
		{
			switch($attrs['data_type'])
			{
				case 'string':
					if($attrs['type'] == 'textarea')
						$attrs['value'] = ng_sanitize_text_field(ng_get_value($field));
					else
						$attrs['value'] = sanitize_text_field(ng_get_value($field));
					break;
				case 'numeric':
					$attrs['value'] = ng_sanitize_digit(ng_get_value($field));
					if(isset($attrs['range']) && !ng_is_number_between($attrs['value'], $attrs['range']['min'], $attrs['range']['max']))
					{
						if($return)
							return array('status' => false, 'field' => $field, 'error' => 'range');
					}
					break;
				case 'array':
					$attrs['value'] = isset($_REQUEST[$field]) && is_array($_REQUEST[$field]) ? $_REQUEST[$field] : array();
					break;
			}
			
			if(isset($attrs['values']))
			{
				if(!isset($attrs['values'][$attrs['value']]))
					$attrs['value'] = '';
			}
			
			update_post_meta($this->ID, $field, $attrs['value']);
			if($return)
				return array('status' => true);
		}
	}
	
	/**
	 * Print component form fields
	 */
	public function print_form_fields()
	{
		$this->meta_values();

		foreach ($this->form_fields as $field => $attrs)
		{
			$this->render_form_input($field, $attrs);
		}
	}
	
	/**
	 * Print a component form field
	 * 
	 * @param string $field
	 * @param array $attrs
	 */
	public function render_form_input($field, $attrs)
	{
		if(isset($attrs['html']) && '' == $attrs['html'])
			return;
		
		if(!isset($attrs['class']))
			$attrs['class'] = '';
		
		if(!isset($attrs['dir']))
			$attrs['dir'] = 'ltr';
		
		echo '<label for="', $field ,'">', $attrs['label'] ,' :</label>';
		if(isset($attrs['label_next']))
			echo ' <span class="description" style="vertical-align:middle;">', $attrs['label_next'] ,'</span>';
		
		echo '<p class="field-', $field ,'">';
		switch($attrs['type'])
		{
			case 'select':
				echo '<select id="', $field ,'" name="', $field ,'"><option value="0"></option>';
				if(isset($attrs['source']))
				{
					foreach ($attrs['source'] as $option_value => $option_label)
					{
						echo '<option value="', $option_value ,'"';
						echo $option_value == $attrs['value'] ? ' selected' : '';
						echo '>', $option_label . '</option>';
					}
				}
				echo '</select>';
				break;
			case 'checkbox':
				if($attrs['is_singular'])
				{
					echo '<label><input type="checkbox" name="', $field ,'" value="', $attrs['input_data']['value'] ,'" ';
					if($attrs['input_data']['value'] == $attrs['value'])
						echo 'checked="checked" ';
					echo '/> ', $attrs['input_data']['label'] ,'</label>';
				}
				else
				{
					foreach($attrs['values'] as $checkbox_value => $checkbox_label)
					{
						echo '<label><input type="checkbox" name="', $field ,'[]" value="', $checkbox_value ,'" ';
						if(in_array($checkbox_value, $attrs['value']))
							echo 'checked="checked" ';
						echo '/> ', $checkbox_label ,'</label>&nbsp;&nbsp;&nbsp;&nbsp;';
					}
				}
				break;
			case 'radio':
				foreach($attrs['values'] as $radio_value => $radio_label)
				{
					echo '<label><input type="radio" name="', $field ,'" value="', $radio_value ,'" ';
					if($radio_value == $attrs['value'])
						echo 'checked="checked" ';
					echo '/> ', $radio_label ,'</label>&nbsp;&nbsp;&nbsp;&nbsp;';
				}
				break;
			case 'text':
				echo '<input type="text" name="', $field ,'" id="', $field ,'" value="', $attrs['value'] ,'" class="', $attrs['class'] ,'" dir="', $attrs['dir'] ,'" /> ';
				break;
			case 'textarea':
				if(!isset($attrs['cols']))
					$attrs['cols'] = '';
				
				if(!isset($attrs['rows']))
					$attrs['rows'] = '';
				
				echo '<textarea name="', $field ,'" id="', $field ,'" rows="', $attrs['rows'] ,'" cols="', $attrs['cols'] ,'" class="', $attrs['class'] ,'" dir="', $attrs['dir'] ,'">', $attrs['value'] ,'</textarea>';
				break;
			case 'html':
				echo $attrs['html'];
				break;
			case 'image':
				if($attrs['media_library'])
				{
					if(!isset($attrs['value']['id']))
						$attrs['value']['id'] = '';

					if(!isset($attrs['value']['url']))
						$attrs['value']['url'] = '';

					$not_empty = '' != $attrs['value']['url'];
					echo '<span style="display:block;" class="image-holder">';
					if($not_empty)
						echo '<img src="'. $attrs['value']['url'] .'" />';

					echo '</span>';
					echo '<input type="button" class="ml-image button" value="Media Library" />';
					echo '<input name="', $field ,'[id]" type="hidden" value="', $attrs['value']['id'] ,'" class="image-id" />';
					echo '<input name="', $field ,'[url]" type="hidden" value="', $attrs['value']['url'] ,'" class="image-url" />';
					echo '&nbsp;&nbsp;<input type="button" class="ml-image-remove button" value="Remove Image" ';
					echo $not_empty ? '' : 'style="display: none;" ';
					echo '/>';
				}
				break;
		}
		
		if(isset($attrs['desc']))
			echo '&nbsp;&nbsp;<span class="description">', $attrs['desc'] ,'<span>';
		
		echo '</p>';
	}
}

















