<?php 
$name=htmlspecialchars($_FILES['img']['name']);
$type=htmlspecialchars($_FILES['img']['type']);
$size=htmlspecialchars($_FILES['img']['size']);
$tmp_name=htmlspecialchars($_FILES['img']['tmp_name']);

 ?>