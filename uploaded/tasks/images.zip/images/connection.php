<?php 
try {
	$conn=new pdo ('mysql:host=localhost;dbname=cv' , 'root' , '');
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	// if ($conn) {
	// 	echo "yup";
	// }
} catch (Exception $e) {
	echo $e->getMessage();
}

 ?>