<?php 
include 'connection.php';
if (isset($_GET['msg'])) {
	$id=$_GET['msg'];
	$sql="DELETE FROM image WHERE id= '$id' ";
	$query=$conn->prepare($sql);
	if ($query->execute()) {
		header("location: show.php?msg=deleted");
		die();
	}
}

 ?>