<?php 
include 'connection.php';
if (isset($_GET['msg'])) {
	$name=$_GET['msg'];
	echo "<img src='image/".$name."' width=100% height=100%>";
}
 ?>