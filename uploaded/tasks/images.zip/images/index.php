<?php 
include 'connection.php';
// include 'vars.php';

$name=htmlspecialchars($_FILES['img']['name']);
$type=htmlspecialchars($_FILES['img']['type']);
$size=htmlspecialchars($_FILES['img']['size']);
$tmp_name=htmlspecialchars($_FILES['img']['tmp_name']);

if (isset($_POST['ok'])) {
	$uplocation="image/";
	$up=move_uploaded_file($tmp_name , $uplocation.$name);
}
$tmp_name=substr(rand(0,1000000000000), 0,9);
if ($type=='image/jpg' || $type=='image/png' || $type=='image/jpeg') {
	$sql="INSERT INTO image values ('',?,?,?,?) ";
	$query=$conn->prepare($sql);
	$query->bindValue(1,$name,PDO::PARAM_STR);
	$query->bindValue(2,$type,PDO::PARAM_STR);
	$query->bindValue(3,$size,PDO::PARAM_INT);
	$query->bindValue(4,$tmp_name,PDO::PARAM_INT);
	$query->execute();
	if ($query) {
		header("location: show.php");
		die();

	}
}



?>