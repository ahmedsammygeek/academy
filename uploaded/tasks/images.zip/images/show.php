<?php 
include 'connection.php';
	$sql="SELECT * FROM image";
	$query=$conn->query($sql);
	$i=0;
	while ($result=$query->fetch(PDO::FETCH_ASSOC)) {
		extract($result);
		echo "<table border=3px width=700px height=115px>
		<tr>
		<td>$i</td>
		<td>$name</td>
		<td>$type</td>
		<td>$size</td>
		<td>$tmp_name<td>
		<td><a href='view.php?msg=$name' target='_balnk'><img src='image/".$name."' width=60px height=100px></a></td>
		<td><a href='delete.php?msg=$id'><button>delete</button></a></td>
		<td><a href='resize.php?msg=$id'><button>resize</button></a></td>

		</tr>
		</table>
		";
		$i++;
	}
	switch (isset($_GET['msg'])) {
		case 'deleted':
			echo "<table border=3px width=700px>your image $name  deleted</table>";
			break;
		
		default:
			
			break;
	}









?>