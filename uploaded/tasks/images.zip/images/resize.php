
 <?php 	
include 'connection.php';
// include 'vars.php';
require_once 'ImageManipulator.php';
if (isset($_GET['msg'])) {
	$id=$_GET['msg'];
	$sql="SELECT * FROM image WHERE id= '$id' ";
	$query=$conn->query($sql);
	while ($result=$query->fetch(PDO::FETCH_ASSOC)) {
		extract($result);
		}
	}
	// var_dump($tmp_name); die();
	// $num=strlen($tmp_name);
	// var_dump($tmp_name); die();
	$tmp_name = 'image/'.$name;
	// var_dump($tmp_name); die();
	$img=new ImageManipulator($tmp_name);
	$newimg=$img->resample(50,50);
	$check = $img->save('image/' . time() . $name);
	if ($newimg) {
		echo "edited";
	}
	else
	{
		echo "null";
	}


 ?>